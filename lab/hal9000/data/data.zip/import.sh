#!/usr/bin/env bash
set -euo pipefail
shopt -s nullglob

BASE_DIR="${1:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
cd "$BASE_DIR"

ES_URL="${ES_URL:?ES_URL n'est pas défini}"
ES_API_KEY="${ES_API_KEY:-${ES_APIKEY:-}}"
: "${ES_API_KEY:?ES_API_KEY (ou ES_APIKEY) n'est pas défini}"

echo "Working dir: $PWD"
echo "ES_URL: $ES_URL"

echo "Auth files:   $(ls -1 bulk_auth_2025-08-*.ndjson 2>/dev/null | wc -l || true)"
echo "API  files:   $(ls -1 bulk_api_2025-08-*.ndjson 2>/dev/null | wc -l || true)"

import_files() {
  local pattern="$1"; shift || true
  local files=( $pattern )
  if (( ${#files[@]} == 0 )); then
    echo "⚠ Aucun fichier pour le motif: $pattern"
    return 0
  fi
  for f in "${files[@]}"; do
    echo "→ Importing $f"
    curl -sS -X POST "$ES_URL/_bulk?refresh=wait_for" \
      -H "Authorization: ApiKey $ES_API_KEY" \
      -H 'Content-Type: application/x-ndjson' \
      --data-binary @"$f" \
      | grep -E '"errors":(true|false)' || true
  done
}

import_files 'bulk_auth_2025-08-*.ndjson'
import_files 'bulk_api_2025-08-*.ndjson'

echo "✅ Terminé"